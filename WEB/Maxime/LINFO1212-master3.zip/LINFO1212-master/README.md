# LINFO1212

.html 
4 parties (header , menu , description et graphiques )


.css
ensemble des styles de l'ensemble et chaque partie individualmente


psd(il y a des styles inutiles que je dois enlever petit a petit )
